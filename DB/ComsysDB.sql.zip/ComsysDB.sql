-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Aug 22, 2015 at 10:51 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `comsystem`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `createproject`
-- 

CREATE TABLE `createproject` (
  `project_ID` int(10) NOT NULL auto_increment,
  `nameThai` varchar(100) NOT NULL,
  `nameEng` varchar(100) NOT NULL,
  `std1` varchar(8) NOT NULL,
  `std2` varchar(8) default NULL,
  `std3` varchar(8) default NULL,
  `pro1` varchar(10) NOT NULL,
  `pro2` varchar(10) default NULL,
  `pro3` varchar(10) NOT NULL,
  PRIMARY KEY  (`project_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

-- 
-- Dumping data for table `createproject`
-- 

INSERT INTO `createproject` VALUES (1, 'เครื่องไล่นกพิราบในอาคาร', 'ProtectPigeon', '55362431', '55362417', '', 'G01', 'G00', 'G04');
INSERT INTO `createproject` VALUES (9, 'เครื่องไล่นกพิราบ', 'ProtectPigeon', '55361076', '', '', 'G01', 'G02', 'G03');

-- --------------------------------------------------------

-- 
-- Table structure for table `logs`
-- 

CREATE TABLE `logs` (
  `Logs_ID` int(10) NOT NULL auto_increment,
  `date` date NOT NULL,
  `title` varchar(100) NOT NULL,
  `note` text NOT NULL,
  `test` varchar(100) default NULL,
  PRIMARY KEY  (`Logs_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `logs`
-- 

INSERT INTO `logs` VALUES (5, '2023-04-15', 'ออกแบบโครงสร้าง', 'จะออกแบบบนโปรแกรม ART CAMPRO', 'ต้องซื้อโปรแกรม');
INSERT INTO `logs` VALUES (6, '2023-04-15', 'ทดสอบ', 'ทดสอบ', 'ทด');

-- --------------------------------------------------------

-- 
-- Table structure for table `profressorregis`
-- 

CREATE TABLE `profressorregis` (
  `Projressor_ID` varchar(10) NOT NULL,
  `password` varchar(16) NOT NULL,
  PRIMARY KEY  (`Projressor_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `profressorregis`
-- 

INSERT INTO `profressorregis` VALUES ('GD120', '1234');
INSERT INTO `profressorregis` VALUES ('GD130', '1234');

-- --------------------------------------------------------

-- 
-- Table structure for table `project_status`
-- 

CREATE TABLE `project_status` (
  `ID` varchar(8) NOT NULL,
  `status_ID` int(10) NOT NULL auto_increment,
  `status_title` varchar(50) NOT NULL,
  `note` varchar(50) default NULL,
  PRIMARY KEY  (`status_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `project_status`
-- 

INSERT INTO `project_status` VALUES ('55362431', 1, 'CPE01', NULL);
INSERT INTO `project_status` VALUES ('55362417', 4, 'CPE01', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `studentregis`
-- 

CREATE TABLE `studentregis` (
  `Student_ID` varchar(8) NOT NULL,
  `password` varchar(16) NOT NULL,
  PRIMARY KEY  (`Student_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `studentregis`
-- 

INSERT INTO `studentregis` VALUES ('55362431', '1234');
INSERT INTO `studentregis` VALUES ('55362417', '1234');
INSERT INTO `studentregis` VALUES ('55361076', 'nong');
INSERT INTO `studentregis` VALUES ('55364293', '1234');

-- --------------------------------------------------------

-- 
-- Table structure for table `students`
-- 

CREATE TABLE `students` (
  `Student_ID` varchar(8) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Faculty` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `info` text NOT NULL,
  `pic_url` text,
  PRIMARY KEY  (`Student_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Dumping data for table `students`
-- 

INSERT INTO `students` VALUES ('55362431', 'สหกรณ์ บัวงาม', 'วิศวกรรมศาสตร์', 'sahakornb55@email.nu.ac.th', '0931975555', 'test', 'images\\members\\sahakorn.jpg');
INSERT INTO `students` VALUES ('55362417', 'ศักดิ์ชัย ศรีโสม', 'วิศวกรรมศาสตร์', 'jumbo@gmail.com', '0931112122', 'test2', 'images\\members\\sakchai.jpg');
INSERT INTO `students` VALUES ('55361076', 'ขวัญชนก  นวลนภาศรี', 'วิศวกรรมศาสตร์', 'Kwanchanokn55@email.nu.ac.th', '0866741496', '', 'images/members/kwanchanok.jpg');
INSERT INTO `students` VALUES ('55364293', 'ประยุทธ์ จันทร์โอชา', 'รัฐมนตรี', 'prayut@gmail.com', '099-1991999', '', 'images/members/thee.jpg');
